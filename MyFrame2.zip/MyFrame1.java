import java.awt.*;

public class MyFrame1 extends Frame{
    public static void main(String[]args){
        MyFrame1 frame = new MyFrame1();
        frame.setSize(600, 500);
        frame.setTitle("Frame With Position");
        frame.setLocation(750, 300);
        frame.setVisible(true);
    }
    

}
