import java.awt.*;

public class MyFrame1 extends Frame{
    public static void main(String[]args){
        MyFrame1 frame = new MyFrame1();
        frame.setSize(500, 400);
        frame.setTitle("Frame");
        frame.setVisible(true);
    }
    

}
